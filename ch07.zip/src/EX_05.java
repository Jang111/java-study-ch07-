class MyPoint3 extends Object{
	int x;
	int y;
	
	public String toString() {
		return "x : "+x+", y : "+y;
	}
}
class Point3d extends MyPoint3{
	int z;
	
	Point3d(int x,int y,int z){
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public String toString() {
		return "x : "+x+", y : "+y+",z : "+z;
	}
}

public class EX_05 {

	public static void main(String[] args) {
		Point3d p = new Point3d(1,2,3);
		System.out.println(p);
	}

}