
public class EX_16 {

	public static void main(String[] args) {
		Car car = new Car();
		Car car2 = null;
		FireEngine fe =null;
		
		car.drive();
		fe = (FireEngine)car;
		fe.drive();
		car2 = (Car)fe;
		car2.drive();
	}

}