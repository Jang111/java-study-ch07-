interface Repairable{}

class Unit3{
	int hitpoint;
	final int MAX_HP;
	Unit3(int hp){
		MAX_HP = hp;
	}
}
class GroundUnit extends Unit3{
	GroundUnit(int hp){
		super(hp);
	}
}

class AirUnit extends Unit3{
	AirUnit(int hp){
		super(hp);
	}
}

class Tank1 extends GroundUnit implements Repairable{
	Tank1(){
		super(150);
		hitpoint = MAX_HP;
	}
	public String toString() {
		return "Tank";
	}
}

class DropShip1 extends GroundUnit implements Repairable{
	DropShip1(){
		super(125);
		hitpoint = MAX_HP;
	}
	public String toString() {
		return "Dropship";
	}
}
class Marine1 extends GroundUnit{
	Marine1(){
		super(40);
		hitpoint = MAX_HP;
	}
}
class SCV extends GroundUnit implements Repairable{
	SCV(){
		super(60);
		hitpoint = MAX_HP;
	}
	void repair(Repairable r) {
		if(r instanceof Unit3) {
			Unit3 u = (Unit3)r;
			while(u.hitpoint!=u.MAX_HP) {
				u.hitpoint++;
			}
		System.out.println(u+"�� ������ �������ϴ�.");
		}
	}
}

public class EX_29 {

	public static void main(String[] args) {
		Tank1 tank = new Tank1();
		DropShip1 dropship = new DropShip1();
		Marine1 marine  = new Marine1();
		SCV scv = new SCV();
		scv.repair(tank);
		scv.repair(dropship);
		
	}
}

