final class Singleton{
	private static Singleton s = new Singleton();
	private Singleton() {
		super();
		//
	}
	public static Singleton getInstance() {
		if(s==null) {
			s = new Singleton();
		}
		return s;
	}
}


public class EX_14 {

	public static void main(String[] args) {
		Singleton s = Singleton.getInstance();
	}

}