package com.codechobo.book;

public class PackageTest {

	public static void main(String[] args) {
		System.out.println("Hello world!!");
	}

}
