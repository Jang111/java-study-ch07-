
public class EX_38 {
	
	
		Object iv = new Object() {void method(){}};
		static Object cv = new Object() {void method(){}};
		void mymethod() {
			Object lv = new Object() {void method(){}};
		}
	
}

