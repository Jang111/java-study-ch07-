class par{
	public void method2() {
		System.out.println("method2() in parent");
	}
}
interface MyInterface{
	default void method1() {
		System.out.println("method1() in MyInterface");
	}
	default void method2() {
		System.out.println("method2() in  MyInterface");
	}
	static void staticMethod() {
		System.out.println("staticMethod() in MyInterface");
	}
}
interface MyInterface1{
	default void method1() {
		System.out.println("method1() in MyInterface1");
	}
	static void staticMethod() {
		System.out.println("staticMethod() in MyInterface1");
	}
}
class chil extends par implements MyInterface, MyInterface1{
	public void method1() {
		System.out.println("method1() in chil");
	}
}

public class EX_32 {

	public static void main(String[] args) {
		chil c =new chil();
		c.method1();
		c.method2();
		MyInterface.staticMethod();
		MyInterface1.staticMethod();
	}
}

