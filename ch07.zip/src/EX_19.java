
public class EX_19 {

	public static void main(String[] args) {
		Parent4 p = new Child4();
		Child4 n = new Child4();
		
		System.out.println("p.x = "+p.x);
		p.method();
		
		System.out.println("n.x = "+n.x);
		n.method();
	}

}
class Parent4{
	int x = 100;
	
	void method() {
		System.out.println("Parent Method");
	}
}
class Child4 extends Parent4{
}
