

public class EX_25 {

	public static void main(String[] args) {
		Unit[] group = {new Marine(), new Tank(), new DropShip()};
		for(int i=0;i<group.length;i++) {
			group[i].move(100,200);
		}
		Marine mar = null;
		if(group[0] instanceof Marine) {
			mar = (Marine)group[0];
		}
	}
}
abstract class Unit{
	int x,y;
	abstract void move(int x,int y);
	void stop() {System.out.println("����");}
}

class Marine extends Unit{
	void move(int x,int y) {
		System.out.println("Marine[x="+x+",y="+y+"]");
	}
	void stimPack() {
		String str="������ ���";
		System.out.println(str);
	}
}
class Tank extends Unit{
	void move(int x, int y) {
		System.out.printf("Tank[x=%d,y=%d]%n",x,y);
	}
	void changemod() {
		System.out.println("���� ��� ��ȯ");
	}
}
class DropShip extends Unit{
	void move(int x, int y) {
		System.out.printf("DropShip[x=%d,y=%d]%n",x,y);
	}
	void load() {}
	void unload() {}
}