class AA{
	void methodAA() {
		II i = InstanceManager.getInstance();
		i.methodBB();
		System.out.println(i.toString());
	}
}
interface II{
	public abstract void methodBB();
}
class BB implements II{
	public void methodBB() {
		System.out.println("methodBB in BB class");
	}
	public String toString() {
		return "class BB";
	}
}
class InstanceManager{
	public static II getInstance() {
		return new BB();
	}
}
public class EX_31 {

	public static void main(String[] args) {
		AA a = new AA();
		a.methodAA();
	}
}

