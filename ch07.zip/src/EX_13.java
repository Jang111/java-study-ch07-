class Time3{
	private int hour, minute, second;
	
	Time3(int hour, int minute, int second){
		SetHour(hour);
		SetMinute(minute);
		SetSecond(second);
	}
	public int GetHour() {return this.hour;}
	public void SetHour(int hour) {
		if(hour<0 || hour>23) return;
		this.hour = hour;
	}
	public int GetMinute() {return this.minute;}
	public void SetMinute(int minute) {
		if(minute<0 || minute>59) return;
		this.minute = minute;
	}
	public int GetSecond() {return this.second;}
	public void SetSecond(int second) {
		if(second<0 || second>59) return;
		this.second = second;
	}
	public String toString() {
		return this.hour+":"+this.minute+":"+this.second;
	}
}


public class EX_13 {

	public static void main(String[] args) {
		Time3 t =new Time3(12,35,30);
		System.out.println(t);
		t.SetHour(t.GetHour()+1);
		System.out.println(t);
	}

}