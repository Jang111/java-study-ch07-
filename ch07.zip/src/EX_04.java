public class EX_04 {

	public static void main(String[] args) {
		//���� ����/
	}

}
class TV1{
	boolean power;
	int channel;
	
	void power() { power=!power;}
	void channelup() {++channel;}
	void channelDown()
	{
		--channel;
	}
}
class VCR{
	boolean power;
	int counter;
	void power() {
		power=!power;
	}
	void play() {
		System.out.println("");
	}
	void stop() {
		System.out.println("");
	}
	void rew() {
		System.out.println("");
	}
	void ff() {
		System.out.println("");
	}
	
}
class TVCR extends TV{
	VCR vcr = new VCR();
	int counter = vcr.counter;
	void play() {
		vcr.play();
	}
	void stop() {
		vcr.stop();
	}
	void rew() {
		vcr.rew();
	}
	void ff() {
		vcr.ff();
	}
	
	
}

